#!/bin/bash
for i in ./*.csv;
do
    echo $i
    cat $i | wc -l
done

